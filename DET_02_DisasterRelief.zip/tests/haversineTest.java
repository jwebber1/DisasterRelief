import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class haversineTest {

    @Test
    void totDistance() {
        assertEquals(0.0, haversine.totDistance(0.0, 0.0, 0.0, 0.0));
        assertEquals(1.0618, haversine.totDistance(39.79,-91.52, 39.79, -91.54));
        assertEquals(38.9473, haversine.totDistance(39.76, -94.85, 39.21, -94.69));
        assertEquals(292.5545, haversine.totDistance(40.34, -94.87, 36.11, -94.63));
    }
}